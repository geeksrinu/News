package com.ristana.newspro.config;
/**
 * Created by hsn on 29/12/2017.
 */
public class Config {
    public static final String BASE_URL     =   "http://192.168.2.5:9696/admin_panel/public_html/api/";
    public static final String TOKEN_APP     =   "8ffr3er3reg67yu20cve98hty47h2uf0dfg4re7fg0wdhn24";
    // Purchases Data : Item Purchase Code
    public static final String ITEM_PURCHASE_CODE =  "7f3cf632-3810-4937-a2f4-473c5f019b44"; // put your Item Purchase Code here when you change the package name
    // SUBSCRIPTION DATA
    public static final String SUBSCRIPTION_ID = "com.ristana.newspro.subs";
    public static final String LICENSE_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAq23MDixvbHzi+PHYemsd5KTKfgVoRshVCkDCyxIyYC932I64E9USD4666kzoAyeFlZHw006AL7S+2GhQ3EtketMDfCLY4Gdan3mk5m2bGdESaGZrvlzg0bJ9b0vyw3mivUXPPH/w6gcd+yisXynWDgRWKLuwgsUr9rDh8mR7xU+fAHYDIuLt+CCwh3FHArx6Qm6zwCcBL4A+u4KTs8wTsL5ZJXFKe5BOgLFgkmc+Owz/RU6DzrlfBxxZDTuYhcqf1CwSnH1ebEA0jJd/A7T/g8vQs/zuzWWmf0DuVsmjSy89b7my7oSuyB5OjXnBWFDsjpH1+IpZ/sG61K60mo99uQIDAQAB"; // PUT YOUR MERCHANT KEY HERE;
    public static final long SUBSCRIPTION_DURATION = 30 ; // PUT SUBSCRIPTION DURATION DAYS HERE;
}